package com.vortexboost.app

import android.app.*
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/** User-enabled, informational overlay. It does not inject input or modify games. */
class GameOverlayService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var windowManager: WindowManager
    private var panel: LinearLayout? = null
    private var expandedPanel: LinearLayout? = null
    private var collapsedPill: TextView? = null
    private var gameLabel: TextView? = null
    private var statsLabel: TextView? = null
    private var lastPackage = ""
    private var collapsed = false
    private var windowParams: WindowManager.LayoutParams? = null

    private val poller = object : Runnable {
        override fun run() {
            if (!Settings.canDrawOverlays(this@GameOverlayService) || !hasUsageAccess()) {
                removePanel()
                handler.postDelayed(this, 1800)
                return
            }
            val foreground = foregroundPackage()
            if (foreground != null && foreground != packageName && isGamePackage(foreground)) {
                showOrUpdatePanel(foreground)
            } else {
                removePanel()
            }
            handler.postDelayed(this, 1400)
        }
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        startAsForeground()
        handler.post(poller)
    }

    private fun startAsForeground() {
        val channelId = "vortex_boost_active"
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "Vortex Boost em execução", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val pending = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, channelId)
            else @Suppress("DEPRECATION") Notification.Builder(this)
        val notification = builder.setContentTitle("Vortex Boost ativo")
            .setContentText("O painel aparece somente sobre jogos detectados")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(pending).setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(7, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else startForeground(7, notification)
    }

    private fun hasUsageAccess(): Boolean {
        val appOps = getSystemService(Context.APP_OPS_SERVICE) as android.app.AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= 29) {
            appOps.unsafeCheckOpNoThrow("android:get_usage_stats", android.os.Process.myUid(), packageName)
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow("android:get_usage_stats", android.os.Process.myUid(), packageName)
        }
        return mode == android.app.AppOpsManager.MODE_ALLOWED
    }

    private fun foregroundPackage(): String? {
        val usage = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val end = System.currentTimeMillis()
        val events = usage.queryEvents(end - 15_000, end)
        val event = UsageEvents.Event()
        var latestTime = 0L
        var latestPackage: String? = null
        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            val resumed = event.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND ||
                (Build.VERSION.SDK_INT >= 29 && event.eventType == UsageEvents.Event.ACTIVITY_RESUMED)
            if (resumed && event.timeStamp >= latestTime) {
                latestTime = event.timeStamp
                latestPackage = event.packageName
            }
        }
        return latestPackage
    }

    private fun isGamePackage(pkg: String): Boolean {
        if (pkg == "com.dts.freefireth" || pkg == "com.dts.freefiremax") return true
        return try {
            val info = packageManager.getApplicationInfo(pkg, 0)
            info.category == ApplicationInfo.CATEGORY_GAME
        } catch (_: Exception) { false }
    }

    private fun showOrUpdatePanel(pkg: String) {
        if (!Settings.canDrawOverlays(this)) return
        if (panel == null) createPanel()
        val label = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (_: Exception) { pkg }
        val isFreeFire = pkg == "com.dts.freefireth" || pkg == "com.dts.freefiremax"
        gameLabel?.text = if (isFreeFire) "FREE FIRE DETECTADO" else "$label  •  JOGO DETECTADO"
        updateMetrics()
        if (lastPackage != pkg || panel?.parent == null) {
            if (panel?.parent == null) {
                try {
                    val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
                    val params = WindowManager.LayoutParams(
                        WindowManager.LayoutParams.WRAP_CONTENT,
                        WindowManager.LayoutParams.WRAP_CONTENT,
                        type,
                        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                        PixelFormat.TRANSLUCENT
                    ).apply { gravity = Gravity.END or Gravity.CENTER_VERTICAL; x = 10; y = 0 }
                    windowParams = params
                    val currentPanel = panel ?: return
                    windowManager.addView(currentPanel, params)
                } catch (_: Exception) { panel = null; return }
            }
            lastPackage = pkg
        }
    }

    private fun createPanel() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = rounded(Color.rgb(15, 9, 25), Color.rgb(139, 65, 220), 18)
            elevation = dp(10).toFloat()
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val title = label("◉  VORTEX BOOST", 17, Color.rgb(207, 164, 255), true)
        header.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        val collapseButton = label("−", 24, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(10), 0, dp(10), 0)
            setOnClickListener { setCollapsed(true) }
        }
        header.addView(collapseButton)
        outer.addView(header)
        gameLabel = label("JOGO DETECTADO", 11, Color.LTGRAY, true).apply { setPadding(0, dp(7), 0, dp(8)) }
        outer.addView(gameLabel)
        statsLabel = label("RAM livre: --  •  Tela: --\nFPS: N/D  •  CPU: N/D", 12, Color.WHITE, false).apply { setPadding(0, 0, 0, dp(9)) }
        outer.addView(statsLabel)
        addAction(outer, "⚡  LIMPEZA SEGURA", Color.rgb(107, 48, 166)) { cleanOwnCache() }
        addAction(outer, "▣  PREPARAR PARA JOGAR", Color.rgb(55, 35, 76)) {
            Toast.makeText(this, "Feche manualmente apps que não estiver usando. O Android controla a memória dos jogos.", Toast.LENGTH_LONG).show()
        }
        val footer = label("FPS não disponível pelo Android nesta leitura", 10, Color.LTGRAY, false).apply { setPadding(0, dp(8), 0, 0) }
        outer.addView(footer)

        val pill = label("V\nB", 16, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(15), dp(12), dp(15))
            background = rounded(Color.rgb(92, 35, 150), Color.rgb(190, 123, 255), 16)
            visibility = View.GONE
            setOnClickListener { setCollapsed(false) }
        }
        outer.addView(pill)
        expandedPanel = outer
        collapsedPill = pill
        panel = outer
        setCollapsed(false)
    }

    private fun setCollapsed(value: Boolean) {
        collapsed = value
        expandedPanel?.let { container ->
            for (i in 0 until container.childCount) {
                val child = container.getChildAt(i)
                if (child === collapsedPill) child.visibility = if (value) View.VISIBLE else View.GONE
                else child.visibility = if (value) View.GONE else View.VISIBLE
            }
        }
        windowParams?.let { params ->
            params.width = WindowManager.LayoutParams.WRAP_CONTENT
            params.height = WindowManager.LayoutParams.WRAP_CONTENT
            try { panel?.let { if (it.parent != null) windowManager.updateViewLayout(it, params) } } catch (_: Exception) {}
        }
    }

    private fun updateMetrics() {
        val manager = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val memory = ActivityManager.MemoryInfo().also { manager.getMemoryInfo(it) }
        val hz = try { @Suppress("DEPRECATION") windowManager.defaultDisplay.refreshRate.toInt() } catch (_: Exception) { 0 }
        statsLabel?.text = "RAM livre: ${memory.availMem / 1048576} MB  •  Tela: ${if (hz > 0) "$hz Hz" else "N/D"}\nFPS: N/D  •  CPU: N/D"
    }

    private fun cleanOwnCache() {
        val bytes = try { cacheDir.walkTopDown().filter { it.isFile }.sumOf { it.length() } } catch (_: Exception) { 0L }
        try { cacheDir.listFiles()?.forEach { it.deleteRecursively() } } catch (_: Exception) {}
        Toast.makeText(this, "Cache do Vortex limpo: ${bytes / 1048576} MB. Nenhum jogo foi alterado.", Toast.LENGTH_LONG).show()
    }

    private fun addAction(parent: LinearLayout, text: String, color: Int, action: () -> Unit) {
        val button = label(text, 13, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(11), dp(10), dp(11))
            background = rounded(color, Color.rgb(150, 83, 216), 10)
            setOnClickListener { action() }
        }
        parent.addView(button, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(7) })
    }

    private fun label(value: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply {
        text = value; textSize = size.toFloat(); setTextColor(color)
        if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
    }

    private fun rounded(fill: Int, stroke: Int, radius: Int) = GradientDrawable().apply {
        setColor(fill); cornerRadius = dp(radius).toFloat(); setStroke(dp(1), stroke)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun removePanel() {
        try { panel?.let { if (it.parent != null) windowManager.removeView(it) } } catch (_: Exception) {}
        panel = null; expandedPanel = null; collapsedPill = null; gameLabel = null; statsLabel = null
        lastPackage = ""; windowParams = null; collapsed = false
    }

    override fun onDestroy() {
        handler.removeCallbacks(poller)
        removePanel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
