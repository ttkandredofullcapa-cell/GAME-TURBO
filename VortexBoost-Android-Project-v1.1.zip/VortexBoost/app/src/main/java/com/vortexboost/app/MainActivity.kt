package com.vortexboost.app

import android.Manifest
import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.util.Locale

class MainActivity : Activity() {
    private val backgroundColor = Color.rgb(9, 7, 15)
    private val cardColor = Color.rgb(27, 19, 39)
    private val purple = Color.rgb(190, 125, 255)
    private lateinit var serviceStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 40)
        }
    }

    override fun onResume() {
        super.onResume()
        if (::serviceStatus.isInitialized) refreshStatus()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(22), dp(18), dp(26))
            setBackgroundColor(backgroundColor)
        }
        val scroll = ScrollView(this).apply { isFillViewport = true; addView(root) }
        setContentView(scroll)

        text(root, "VORTEX", 31, Color.WHITE, true)
        text(root, "BOOST  /  GAME PERFORMANCE", 12, purple, true, 2)
        text(root, "CENTRAL DE COMANDO GAMER", 11, Color.LTGRAY, true, 22)

        val hero = card(root)
        text(hero, "MODO GAME TURBO", 12, purple, true)
        text(hero, "Seu jogo. Seu desempenho.", 20, Color.WHITE, true, 7)
        text(hero, "Ative o monitoramento para mostrar o painel somente quando um jogo compatível estiver aberto.", 13, Color.LTGRAY, false, 6)
        serviceStatus = text(hero, "Verificando permissões...", 12, Color.rgb(214, 190, 238), true, 14)
        action(hero, "ATIVAR GAME TURBO", purple) { enableTurbo() }
        action(hero, "DESATIVAR GAME TURBO", Color.rgb(83, 60, 105)) {
            stopService(Intent(this, GameOverlayService::class.java))
            serviceStatus.text = "Game Turbo desativado"
            toast("Vortex Boost desativado")
        }

        val metrics = card(root)
        text(metrics, "MONITOR DO APARELHO", 12, purple, true)
        updateDeviceMetrics(metrics)

        val tools = card(root)
        text(tools, "FERRAMENTAS GAMER", 12, purple, true)
        action(tools, "LIMPEZA RÁPIDA SEGURA", purple) { cleanOwnCache() }
        action(tools, "ABRIR FREE FIRE", Color.rgb(99, 54, 139)) { launchFreeFire() }
        action(tools, "CONFIGURAR ACESSO DE USO", Color.rgb(63, 46, 81)) {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }
        action(tools, "CONFIGURAR SOBREPOSIÇÃO", Color.rgb(63, 46, 81)) { requestOverlayPermission() }

        val notes = card(root)
        text(notes, "TRANSPARÊNCIA", 12, purple, true)
        text(notes, "FPS real e uso de CPU por jogo não são disponibilizados universalmente pelo Android. O app mostra N/D quando não consegue medir. A limpeza remove somente arquivos temporários do próprio Vortex Boost; ela não apaga cache de outros apps nem promete aumento artificial de FPS.", 12, Color.LTGRAY, false, 7)
        text(root, "VORTEX BOOST  •  VERSÃO 1.1", 10, Color.GRAY, false, 18)
    }

    private fun enableTurbo() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            requestOverlayPermission()
            toast("Permita sobreposição e toque em Ativar novamente")
            return
        }
        if (!hasUsageAccess()) {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            toast("Ative o acesso de uso do Vortex Boost e volte ao app")
            return
        }
        try {
            val serviceIntent = Intent(this, GameOverlayService::class.java)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(serviceIntent) else startService(serviceIntent)
            serviceStatus.text = "MONITORAMENTO ATIVO • PAINEL SOMENTE EM JOGOS DETECTADOS"
            toast("Game Turbo ativado")
        } catch (error: Exception) {
            serviceStatus.text = "Não foi possível iniciar. Verifique as permissões."
            toast("Falha ao iniciar: ${error.localizedMessage ?: "erro do Android"}")
        }
    }

    private fun requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } else toast("Permissão de sobreposição já liberada")
    }

    private fun hasUsageAccess(): Boolean {
        val appOps = getSystemService(Context.APP_OPS_SERVICE) as android.app.AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= 29) {
            appOps.unsafeCheckOpNoThrow("android:get_usage_stats", android.os.Process.myUid(), packageName)
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow("android:get_usage_stats", android.os.Process.myUid(), packageName)
        }
        return mode == android.app.AppOpsManager.MODE_ALLOWED
    }

    private fun refreshStatus() {
        val overlayGranted = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this)
        val usageGranted = hasUsageAccess()
        serviceStatus.text = when {
            overlayGranted && usageGranted -> "PERMISSÕES PRONTAS • ATIVE O GAME TURBO"
            !overlayGranted -> "FALTA PERMISSÃO DE SOBREPOSIÇÃO"
            else -> "FALTA PERMISSÃO DE ACESSO DE USO"
        }
    }

    private fun updateDeviceMetrics(parent: LinearLayout) {
        val activityManager = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val memory = ActivityManager.MemoryInfo().also { activityManager.getMemoryInfo(it) }
        val hz = try { @Suppress("DEPRECATION") windowManager.defaultDisplay.refreshRate.toInt() } catch (_: Exception) { 0 }
        text(parent, "RAM livre: ${formatBytes(memory.availMem)}", 15, Color.WHITE, true, 9)
        text(parent, "Taxa de atualização da tela: ${if (hz > 0) "$hz Hz" else "Não disponível"}", 13, Color.LTGRAY, false, 5)
        text(parent, "FPS: N/D  •  CPU: N/D  •  Temperatura: N/D", 12, Color.LTGRAY, false, 5)
    }

    private fun cleanOwnCache() {
        val bytes = try { cacheDir.walkTopDown().filter { it.isFile }.sumOf { it.length() } } catch (_: Exception) { 0L }
        try { cacheDir.listFiles()?.forEach { safeDelete(it) } } catch (_: Exception) {}
        toast("Cache temporário do Vortex removido: ${formatBytes(bytes)}")
    }

    private fun safeDelete(file: File) { try { file.deleteRecursively() } catch (_: Exception) {} }

    private fun launchFreeFire() {
        val packages = listOf("com.dts.freefireth", "com.dts.freefiremax")
        val launchIntent = packages.firstNotNullOfOrNull { packageManager.getLaunchIntentForPackage(it) }
        if (launchIntent != null) startActivity(launchIntent) else toast("Free Fire ou Free Fire MAX não foi encontrado")
    }

    private fun card(parent: LinearLayout): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(15), dp(16), dp(15))
        background = GradientDrawable().apply { setColor(cardColor); cornerRadius = dp(17).toFloat(); setStroke(dp(1), Color.rgb(76, 48, 101)) }
        parent.addView(this, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(15) })
    }

    private fun text(parent: LinearLayout, value: String, size: Int, color: Int, bold: Boolean, top: Int = 0): TextView {
        val view = TextView(this).apply {
            text = value; textSize = size.toFloat(); setTextColor(color)
            if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setPadding(0, dp(top), 0, 0)
        }
        parent.addView(view, LinearLayout.LayoutParams(-1, -2))
        return view
    }

    private fun action(parent: LinearLayout, title: String, color: Int, run: () -> Unit) {
        val button = Button(this).apply {
            text = title; textSize = 12f; isAllCaps = false; setTextColor(Color.WHITE)
            setBackgroundColor(color); setOnClickListener { run() }
        }
        parent.addView(button, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
    }

    private fun formatBytes(bytes: Long): String = String.format(Locale.getDefault(), "%.0f MB", bytes / 1048576.0)
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}
