plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.vortexboost.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.vortexboost.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "1.1"
    }
}
